export { registerDclEvents } from "../../lib/eventListeners"
